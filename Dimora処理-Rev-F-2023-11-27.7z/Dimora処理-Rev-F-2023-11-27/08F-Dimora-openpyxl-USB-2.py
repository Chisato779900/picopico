# usr/bin/env python
# coding: utf-8
# print(i,end='')

'''
「ディモーラ」サイトの「TSV形式」のデータに合わせて修正中
'''
# =============== import
import openpyxl
from openpyxl.styles import Alignment, PatternFill, Font, Border, Side
from glob import glob
import os
from datetime import datetime
import datetime
import shutil
# =============== CD チェンジディレクトリ
os.chdir('C:\\pypy\\Dimora')
cwd = os.getcwd()
print(cwd)
now = datetime.datetime.now()
print('作成年月日')
print('{0:%Y-%m-%d %H:%M}'.format(now)) #test_2017-09-10 10:12
date_now = ('{0:%Y/%m/%d}'.format(now)) #test_2017-09-10 10:12
time_now = ('{0:%H:%M}'.format(now)) #test_2017-09-10 10:12

# =============== 入力ファイル名　固定化
input_file_name = '2W101-USB-2-pandas-output.xlsx'
#                  2W101-USB-2-pandas-output
wb = openpyxl.load_workbook(input_file_name)
ws = wb.active
# =============== 出力ファイル名　固定化
output_file_name = '2W101-番組表-USB-2-py.xlsx'
# =============== 変数の定義
# (media)
# media = 'Verbatim BD-R_DL 50GB 67:50_x15_45552MB'
media = 'DMR-2W101 1TB 1407:51__X15__942872MB'
# media = 'P社 BD-RE 25GB 67:50_x15_45552MB'
# =============== 表情報記入　列指定
TTT = 7
# =============== 罫線の「なん列」まで作成
# 使用列「+1」を設定
KEISEN = 20
# =============== 表先頭の空白行の「挿入行数」
# INS_GYOU = 2
INS_GYOU = 3 # 2023-06-28 変更
# =============== 背景色　line_no_back_color で　行指定
# line_no_back_color = 3
line_no_back_color = 4
# line_no_back_color = 5
# col_no_back_color = 21 未使用
# =============== 行数の取得と変数化と変数の表示
max_row = ws.max_row
print(max_row,end=' ')
print("行")
# =============== カラム数の取得と変数化と変数の表示
max_col = ws.max_column
print(max_col,end=' ')
print("列")
# =============== 行の高さ　指定　表全体
# 削除
# =============== 列幅（カラム幅）の　個別指定
col_width = {'A':10,'B':3,'C':4,'D':9,
'E':57,     # 57=11.37cm 58=11.37cm 
'F':3,'G':3,'H':7,'I':5,
'J':3,'K':10,'L':8,
'M':10,'N':5,'O':6,'P':6,'Q':6,'R':5,'S':4,
'T':2,'U':2,'V':2,'W':2,'X':2,'Y':2,'Z':2}

for col , width in col_width.items():
	ws.column_dimensions[col].width = width

# =============== 表の情報記入
title_no = max_row-1
ws.cell(row=(max_row)+1,column=5).value=str(title_no)+" 番組   "+str(max_col)+" 列"
# =============== 空白行の挿入
# 挿入開始行数（1行目に挿入)
SheetRowNo=1
# データ先頭の備考記入欄　空白行挿入　7行　⇒　9行 ⇒　1行
for x in range(INS_GYOU):      # (x)回実行　ゆえに　(x)行挿入
    ws.insert_rows(SheetRowNo) #1行挿入
# =======================　文字列　カラム名　等の　入力(1)
# ======================== 表タイトル記入
# row = 1     # A-1 ほか
# row = 2     # 予備【曜日・開始時間】
# row = 3     # 曜日・開始時間
# row = 4     # 曜日・開始時間

ws.cell(row=1,column=1).value   = 'A-1'
ws.cell(row=2,column=1).value   = '◆WEEKDAY(A5)'
ws.cell(row=4,column=1).value   = '放送開始日時'
ws.cell(row=1,column=2).value   = 'B-2'
ws.cell(row=3,column=2).value   = '曜'
ws.cell(row=4,column=2).value   = '日'
ws.cell(row=1,column=3).value   = 'C-3'
ws.cell(row=3,column=3).value   = '開始'
ws.cell(row=1,column=4).value   = 'D-4'
ws.cell(row=1,column=5).value   = 'E-5'+(date_now)+'   '+(time_now)
ws.cell(row=2,column=5).value   = (media)
ws.cell(row=3,column=5).value   = ' 木漏れ日ｺﾞｼｯｸ 6pt 太字'
ws.cell(row=4,column=5).value   = '☆☆☆☆☆　番組タイトル　☆☆☆☆☆'
ws.cell(row=1,column=6).value   = 'F-6'
ws.cell(row=1,column=7).value   = 'G-7 '
ws.cell(row=1,column=8).value   = 'H-8'           # H-14
ws.cell(row=1,column=9).value   = 'I-9'
ws.cell(row=1,column=10).value   = 'J-10'         # J-14
ws.cell(row=1,column=11).value   = 'K-11'         # K-14
ws.cell(row=2,column=11).value   = '◆J5/1440' # N-14
ws.cell(row=3,column=11).value   = '◆[h]:mm' # N-14
ws.cell(row=1,column=12).value   = 'L-12'         # L-14
ws.cell(row=1,column=13).value = 'M-13'         # M-14
ws.cell(row=1,column=14).value = 'N-14'         # N-14
ws.cell(row=1,column=15).value = 'O-15'         # O-14
ws.cell(row=1,column=16).value = 'P-16'         # P-14
ws.cell(row=2,column=16).value = 45542        # N-14
ws.cell(row=1,column=17).value = 'Q-17'         # P-14
ws.cell(row=2,column=17).value = 'MB'         # O-14
ws.cell(row=1,column=18).value = 'R-18'         # P-14
ws.cell(row=1,column=19).value = 'S-19'         # P-14
# ws.cell(row=(l_no1),column=20).value   = 'T-20'         # P-14
# ws.cell(row=(l_no1),column=21).value   = 'U-21'         # P-14

# =============== R列　「MB」
xxx = 5
for i in range(max_row-1):
    ws.cell(row=(xxx),column=18).value = 'MB'
    xxx = xxx + 1

# =============== S列　「%」
xxx = 5
for i in range(max_row-1):
    ws.cell(row=(xxx),column=19).value = '%'
    xxx = xxx + 1


# =============== シートを取得
# ws['L5'] = '=E5/1440'
# ws['M5'] = '=H5'
# ws['M5'] = '=H5'
# シート変数.cell(row=行,column=列).value = 書き込む値

# =============== 列ごとに　セルの表示位置
# =============== 左寄せ・中央・右寄せ　の設定

for row in ws["A5:A300"]:
    for cell in row:
        # cell.alignment = Alignment(horizontal="centerContinuous")
        cell.alignment = Alignment(horizontal="left")
        # cell.alignment = Alignment(horizontal="right")

for row in ws["B5:B300"]:
    for cell in row:
        # cell.alignment = Alignment(horizontal="centerContinuous")
        # cell.alignment = Alignment(horizontal="left")
        cell.alignment = Alignment(horizontal="center")
        # cell.alignment = Alignment(horizontal="right")

for row in ws["C5:C300"]:
    for cell in row:
        cell.alignment = Alignment(horizontal="right")
        cell.number_format = "hh:mm"        

for row in ws["D5:D300"]:
    for cell in row:
        # cell.alignment = Alignment(horizontal="centerContinuous")
        cell.alignment = Alignment(horizontal="left")
        # cell.alignment = Alignment(horizontal="right")

for row in ws["E5:E300"]:
    for cell in row:
        # cell.alignment = Alignment(horizontal="centerContinuous")
        # cell.number_format = '#,##0'
        cell.alignment = Alignment(horizontal="left")
        # cell.alignment = Alignment(horizontal="right")

for row in ws["F5:F300"]:
    for cell in row:
        # cell.alignment = Alignment(horizontal="centerContinuous")
        cell.alignment = Alignment(horizontal="left")

for row in ws["G5:G300"]:
    for cell in row:
        # cell.alignment = Alignment(horizontal="centerContinuous")
        cell.alignment = Alignment(horizontal="left")

for row in ws["H4:H300"]:
    for cell in row:
        # cell.alignment = Alignment(horizontal="centerContinuous")
        cell.alignment = Alignment(horizontal="right")
        # cell.number_format = "hh:mm"
        cell.number_format = "[h]:mm"

for row in ws["I4:I300"]:
    for cell in row:
        cell.alignment = Alignment(horizontal="right")
        
for row in ws["J4:J300"]:
    for cell in row:
        cell.alignment = Alignment(horizontal="right")
        
for row in ws["K4:K300"]:
    for cell in row:
        # cell.alignment = Alignment(horizontal="centerContinuous")
        # cell.alignment = Alignment(horizontal="left")
        cell.alignment = Alignment(horizontal="right")

for row in ws["L4:L300"]:
    for cell in row:
        # cell.alignment = Alignment(horizontal="centerContinuous")
        cell.alignment = Alignment(horizontal="left")
        # cell.alignment = Alignment(horizontal="right")
        

for row in ws["M5:M300"]:
    for cell in row:
        # cell.alignment = Alignment(horizontal="centerContinuous")
        cell.alignment = Alignment(horizontal="left")
        cell.number_format = openpyxl.styles.numbers.FORMAT_TEXT

for row in ws["N5:N300"]:
    for cell in row:
        # cell.alignment = Alignment(horizontal="centerContinuous")
        cell.number_format = '#,##0'
        # cell.alignment = Alignment(horizontal="left")
        cell.alignment = Alignment(horizontal="right")
        # cell.number_format = openpyxl.styles.numbers.FORMAT_TEXT

for row in ws["O5:O300"]:
    for cell in row:
        # cell.alignment = Alignment(horizontal="centerContinuous")
        # cell.alignment = Alignment(horizontal="left")
        cell.alignment = Alignment(horizontal="right")
        # cell.number_format = '####.#'
        cell.number_format = '#,##0'
        # cell.number_format = '0.000' # 小数点以下第３位（３ケタ）まで表示させる

for row in ws["P5:P300"]:
    for cell in row:
        # cell.alignment = Alignment(horizontal="centerContinuous")
        # cell.alignment = Alignment(horizontal="left")
        cell.alignment = Alignment(horizontal="right")
        # cell.number_format = '####.#'
        cell.number_format = "hh:mm"
        
for row in ws["Q5:Q300"]:
    for cell in row:
        # cell.alignment = Alignment(horizontal="centerContinuous")
        cell.alignment = Alignment(horizontal="left")
        cell.number_format = openpyxl.styles.numbers.FORMAT_TEXT

for row in ws["R5:R300"]:
    for cell in row:
        # cell.alignment = Alignment(horizontal="centerContinuous")
        # cell.alignment = Alignment(horizontal="left")
        cell.alignment = Alignment(horizontal="center")
        # cell.alignment = Alignment(horizontal="right")
        # cell.number_format = '####.#'
        # cell.number_format = '#,##0'
        cell.number_format = openpyxl.styles.numbers.FORMAT_TEXT

for row in ws["S5:S300"]:
    for cell in row:
        # cell.alignment = Alignment(horizontal="centerContinuous")
        cell.alignment = Alignment(horizontal="left")
        # cell.alignment = Alignment(horizontal="right")
        # cell.number_format = '####.#'
        cell.number_format = openpyxl.styles.numbers.FORMAT_TEXT
        # cell.number_format = '#,##0'
'''
for row in ws["T5:T200"]:
    for cell in row:
        # cell.alignment = Alignment(horizontal="centerContinuous")
        cell.alignment = Alignment(horizontal="left")
        # cell.alignment = Alignment(horizontal="right")
        # cell.number_format = '####.#'
        cell.number_format = openpyxl.styles.numbers.FORMAT_TEXT

for row in ws["U5:U200"]:
    for cell in row:
        # cell.alignment = Alignment(horizontal="centerContinuous")
        # cell.alignment = Alignment(horizontal="left")
        cell.alignment = Alignment(horizontal="right")
        # cell.number_format = '####.#'
        cell.number_format = openpyxl.styles.numbers.FORMAT_TEXT
'''

# ==========================================================
for row in ws["A1:U4"]: # セルの位置表示
    for cell in row:
        # cell.alignment = Alignment(horizontal="centerContinuous")
        cell.alignment = Alignment(horizontal="center")
        
for row in ws["I1:I4"]: # セルの位置表示
    for cell in row:
        # cell.alignment = Alignment(horizontal="centerContinuous")
        cell.alignment = Alignment(horizontal="center")



# ws.cell(row=4,column=14).alignment = Alignment(horizontal="center")
ws['N4'] .alignment = Alignment(horizontal="center")
# ws["N4"]:
# cell.alignment = Alignment(horizontal="cebter")

# =============== 表示　ズーム　２００％　に設定
ws.sheet_view.zoomScale = 200

# =============== 列Ｂの「曜日」の変数
week_day = 5
for i in range(max_row-1):
    ws.cell(row=week_day,column=2).value = '=WEEKDAY(A5)'
    cell.number_format = 'aaa'
    week_day = week_day + 1

# =============== 背景色を変更 背景色
fill = openpyxl.styles.PatternFill(patternType='solid',
                                   # fgColor='FF0000', bgColor='FF0000') # 真っ赤
                                   fgColor='F0E68C', bgColor='F0E68C') # カーキ色 クリーム色　うすい黄色
# =============== 背景の塗る場所　指定
# =============== シートに設定
# =============== 変数　line_no_back_color で　3行目指定
ws.cell(row=(line_no_back_color)-1,column=2).fill = fill      # B列
ws.cell(row=(line_no_back_color)-1,column=3).fill = fill      # B列
# 変数　column　で　２行目の　塗る　セル列を　順次指定
ws.cell(row=(line_no_back_color),column=1).fill = fill      # A列
ws.cell(row=(line_no_back_color),column=2).fill = fill      # B列
ws.cell(row=(line_no_back_color),column=3).fill = fill      # C列
ws.cell(row=(line_no_back_color),column=4).fill = fill      # D列
ws.cell(row=(line_no_back_color),column=5).fill = fill      # E列
ws.cell(row=(line_no_back_color),column=6).fill = fill      # F列
ws.cell(row=(line_no_back_color),column=7).fill = fill      # G列
ws.cell(row=(line_no_back_color),column=8).fill = fill      # H列
ws.cell(row=(line_no_back_color),column=9).fill = fill      # I列
ws.cell(row=(line_no_back_color),column=10).fill = fill     # J列
ws.cell(row=(line_no_back_color),column=11).fill = fill     # K列
ws.cell(row=(line_no_back_color),column=12).fill = fill     # L列
ws.cell(row=(line_no_back_color),column=13).fill = fill     # M列
ws.cell(row=(line_no_back_color),column=14).fill = fill     # N列
ws.cell(row=(line_no_back_color),column=15).fill = fill     # O列
ws.cell(row=(line_no_back_color),column=16).fill = fill     # P列
ws.cell(row=(line_no_back_color),column=17).fill = fill
ws.cell(row=(line_no_back_color),column=18).fill = fill
ws.cell(row=(line_no_back_color),column=19).fill = fill
# ws.cell(row=(line_no_back_color),column=20).fill = fill
# ws.cell(row=(line_no_back_color),column=21).fill = fill

# =============== 余白
ws.page_margins.left   = 0.3          # 元の値　0.4
ws.page_margins.right  = 0.3          # 元の値　0.4
ws.page_margins.top    = 0.7          # 元の値　0.4
ws.page_margins.bottom = 0.7          # 元の値　0.4

ws.page_margins.header = 0
ws.page_margins.footer = 0

# =============== 印刷の向き（横）
ws.page_setup.orientation = 'landscape'
ws.oddFooter.center.text = "&[Page] / &Nページ" #現在のページ、総ページをフッターに設定 ITおじさん
# ws.oddFooter.center.text = &quot;&amp;[Page] / &amp;N ページ&quot;    #Google検索

# =============== 行数 と 列数 を 表示
# =============== ファイル名の印刷
linex = (max_row) + 11      # 8 >>>> 9 Rev.D 11

# print(max_colinex)
# print(max_col)
# print("列")

# font2 = Font(name='木漏れ日ゴシック',size=9, bold=True, color='000000')
font2 = Font(name='木漏れ日ゴシック',size=8, bold=True, color='000000')
# ws['A1'].font = font1

# =============== セル罫線
from openpyxl.styles import Border, Side

# print ("max_row")
# print (max_row)
# print ("max_col")
# print (max_col)

# =============== セル罫線 ボーダー　枠線　の設定　sideオプション
side = Side(style='thin', color='000000')
border = Border(left=side, right=side, top=side, bottom=side)
# line_1 = int(row + 5)
n = max_row

# =============== 罫線(外枠)を設定
border = Border(top=Side(style='thin', color='000000'), 
                bottom=Side(style='thin', color='000000'), 
                left=Side(style='thin', color='000000'),
                right=Side(style='thin', color='000000')
)

# xxx = max_row + 12
xxx = max_row + 4

# セルに罫線を設定
for row_num in range(1,xxx):
    # for col_num in range(1,16):
    # range(1,12) > (1,14)
    
# =============== 罫線の範囲　変数　KEISEN
    for col_num in range(1,(KEISEN)):
        ws.cell(row=row_num ,column=col_num).border = border

xxx = 3
for i in range(max_row-1):
   xxx = xxx + 1


# ==========================================================
#                 openpyxl フォント設定
# ==========================================================
# =============== font_all 全体
# font = Font(name='木漏れ日ゴシック',size=10, bold=True, color='000000')
font_all = Font(name='木漏れ日ゴシック',size=6, bold=True, color='000000')

for row in ws:
    for cell in row:
        ws[cell.coordinate].font = font_all


# =============== font_1 番組タイトル
# font_3 = Font(name='木漏れ日ゴシック',size=6, bold=True, color='000000')
# font_1 = Font(name='00コミック7',size=9, bold=False, color='000000')
font_1 = Font(name='00コミック7',size=10, bold=False, color='000000')


aaa = 1
for i in range(max_row+4):
    ws.cell(row=(aaa),column=5).font = font_1
    aaa = aaa + 1

# =============== font_2 頁行時分分
font_2 = Font(name='木漏れ日ゴシック',size=10, bold=True, color='000000')

row_y = 4
for i in range(max_row+4):
    ws.cell(row=row_y,column=6).font = font_2
    row_y = row_y + 1

row_y = 4
for i in range(max_row+4):
    ws.cell(row=row_y,column=7).font = font_2
    row_y = row_y + 1

row_y = 4
for i in range(max_row+4):
    ws.cell(row=row_y,column=8).font = font_2
    row_y = row_y + 1

row_y = 4
for i in range(max_row+4):
    ws.cell(row=row_y,column=9).font = font_2
    row_y = row_y + 1

for row in ws["F5:H300"]: # セルの位置表示
    for cell in row:
        cell.alignment = Alignment(horizontal="right")
        
# ==========================================================
# ws1のセルをws2にコピー
# ws2['A1'].value = ws1['B2'].value
# ===============
# wb = openpyxl.load_workbook(input_file_name)
# ws = wb.active
# bk = openpyxl.load_workbook(r'C:\temp\foo.xlsx')

ws = wb.worksheets[0]
wb.copy_worksheet(ws)
wb.copy_worksheet(ws)
wb.copy_worksheet(ws)
wb.copy_worksheet(ws)
wb.copy_worksheet(ws)
# =============== シートの名前定義
ws = wb.worksheets[0]
ws.title ="DIGA"
ws = wb.worksheets[1]
ws.title ="DIGA-2"
ws = wb.worksheets[2]
ws.title ="DIGA-3"
ws = wb.worksheets[3]
ws.title ="DIGA-4"
ws = wb.worksheets[4]
ws.title ="DIGA-5"
ws = wb.worksheets[5]
ws.title ="DIGA-6"

# =============== 終了メッセージ
print ("xlsx から openxpyl への整形が完了しました。")
print ("ファイルの出力を実行しました")

# =============== ワークブックの保存（ファイル名＋拡張子）
wb.save(output_file_name)
# =============== END END END END END END END END END
# =============== END END END END END END END END END
# =============== END END END END END END END END END
# =============== END END END END END END END END END
# =============== END END END END END END END END END

# シートを変数格納
# ws1 = wb['Sheet1']
# ws2 = wb['Sheet2']
# ws3 = wb['Sheet3']
# ws4 = wb['Sheet4']
# ws5 = wb['Sheet5']

#ws1のセルをws2にコピー
# ws2['A1'].value = ws1['B2'].value


