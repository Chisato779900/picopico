# ==========================================================
# 2023-07-31-月 INPUT文で　USB-1,USB-2,BRZ1020の切換に着手



# 注意　タイトル行　の　置換後「文字列」を変更した場合
# pandas の　ソート条件・ドロップ条件の見直しが
# 必要かもしれません。
# ==========================================================

import os
import re
import pathlib
import glob
import shutil
import datetime as d
# =============== CD チェンジディレクトリ
# os.chdir('/Users/kinocode/Documents/python/1min/test')
# C:\pypy\DIGA\DIGA-replace\DIGA-replace-UTF2\RECLIST.csv
# os.chdir(r'C:\pypy\DIGA\DIGA-replace\DIGA-replace-UTF2')
os.chdir(r'C:\pypy\Dimora')
cwd = os.getcwd() # こっちは　ＯＫ！
print(cwd)
# ==========================================================
# ===============　INPUT
print('2W101-USB-HDD-1 なら 「1」')
print('2W101-USB-HDD-2 なら 「2」')
print('BRZ1020-USB-HDD-なし なら 「3」')
# ダメです　str型だから　select_hard = input('対象機器を入力してください。＞＞＞')
# ===============　input文を　int(input(ほにゃらら))で囲む
select_hard = int(input('対象機器を入力してください。＞＞＞'))
print(select_hard)
if select_hard == 1:
    print('USB-HDD-1 が選択されました')
    usb_name = "USB-1"
elif select_hard == 2:
    print('USB-HDD-2 が選択されました')
    usb_name = "USB-2"
elif select_hard == 3:
    print('BRZ1020 が選択されました')
    usb_name = "BRZ1020"
else:
    print('ハードウェア情報が正しく認識されませんでした')
    usb_name = "なぞ"
        


# ==========================================================
# BATファイルで処理していた　初期の　ファイルコピー　リネームを
# python化
# ==========================================================
# 【python】ファイルの条件を指定して一括移動する方法【コード解説】
# https://yuruikurashi.com/%E3%80%90python%E3%80%91%E3%83%95%E3%82%A1%E3%82%A4%E3%83%AB%E3%81%AE%E6%9D%A1%E4%BB%B6%E3%82%92%E6%8C%87%E5%AE%9A%E3%81%97%E3%81%A6%E4%B8%80%E6%8B%AC%E7%A7%BB%E5%8B%95%E3%81%99%E3%82%8B%E6%96%B9/

# C:\pypy\DIGA\DIGA-replace\DIGA-replace-UTF2\path_lib_test-Rev-A.py
# 2022/12/28 12:17:12
# 2023-01-14-土曜日　20:04

# 前処理(1)　前回のゴミが残っていたら削除する
# os.remove('UTF-2W101-本体のみ-番組タイトルでソート済.xlsx')

# 前処理(2)ファイルぼMove先のフォルダの存在確認とその処理
if os.path.isdir('F:\\D-DIGA\\_02-tsv-2W101'):
    pass

else:
    os.makedirs('F:\\D-DIGA\\_02-tsv-2W101', exist_ok=True)


#移動元と移動先(copy2)のフォルダを定義する。
input_path = "C:\\Users\\piyop\\Downloads\\"
# output_path = "C:\\pypy\\DimoraDIGA\\DIGA-replace\\DIGA-replace-UTF2\\"
output_path = "C:\\pypy\\Dimora\\"
output_path_2 = "F:\\D-DIGA\\_02-TSV-2W101\\"



# 本日の処理したファイルの格納フォルダを作成

# strftimr() を　使用する方法＿改造-Rev.D
print('strftimr() を　使用する方法＿改造-Rev.D')
now = d.datetime.now()
now_str=d.datetime.strftime(now, '番組表'+'%Y-%m-%d_%H%M%S'+'-2W101-')
print(now_str)
os.makedirs((now_str), exist_ok=True)
print(type(now_str))


#正規表現×glob.globでinput_path内のファイル全てをリストとして取得

#リストの要素を一つずつ取り出して移動(copy2)させていく。
# F:\D-DIGA の　所定フォルダに　ディモーラサイトから
# ダウンロードしたままの状態(*.tsv)で保存
move_file_list = glob.glob(input_path + "*.tsv")
for item in move_file_list:
    shutil.copy2(item, output_path_2)

#　NG>>>　テキストファイルを操作。
# *.tsv を　copy2 後　Rename RECLIST-連番.csv

move_file_list = glob.glob(input_path + "reclist*.tsv")

for i, item in enumerate(move_file_list):
    # shutil.copy2(item, output_path + "moved_" + str(i) + ".csv")
    shutil.copy2(item, output_path + "RECLIST-" + str(i) + ".csv")

# ==========================================================
# 処理(replace)対象ファイルの指定

with open("RECLIST-0.csv", "r" , encoding='UTF-8') as f:
    s = f.read()
# ==========================================================
# replace作業 その１　tsv ⇒ csv


# 番組名などに　半角カンマが含まれていた場合の　tsv ⇒ csv の前処理
s = s.replace(",", "，")

# Dimoraからのダウンロードファイル形式tsv ⇒ csv
s = s.replace("\t", ",")

# openpyxlで　時間　の　バグる現象の回避処理　0:00 ⇒ 0:01
s = s.replace("0:00", "0:01")
# ==========================================================
s = s.replace(",,,,,,,,", "")
s = s.replace(",,,,,,,", "")
s = s.replace(",,,,,,", "")
s = s.replace(",,,,,", "")
s = s.replace(",,,,", "")
s = s.replace(",,,,", "")
s = s.replace(",,,", "")
# ==========================================================
# =============== タイトル行 ★★★　pandasに影響　★★★
# 機器名称	放送開始日時	放送局名	録画時間 (分)	ジャンル	録画先
# 視聴/未視聴	録画モード	タイトル
s = s.replace("機器名称", "DMR-")
s = s.replace("放送開始日時", "□放送開始日時□")
s = s.replace("放送局名", "□放送局□")
# s = s.replace("放送局名", "▽放送局▽") 旧Ver.
s = s.replace("録画時間 (分)", "分")
s = s.replace("ジャンル", "ｼﾞｬﾝﾙ")    # 2022-12-09 追加
# s = s.replace("録画先", "録画場所")   # 2023-07-31 追加
s = s.replace("視聴／未視聴", "視聴")
s = s.replace("録画モード", "MODE")
s = s.replace("タイトル", "☆番組タイトル☆")

# =============== 録画情報の修正
s = s.replace("DMR-2W101", "2W101")
s = s.replace("DMR-BRZ1020", "BRZ1020")
# s = s.replace("録画先", "録画場所")
# s = s.replace("USB-HDD", "USB-1")
# s = s.replace("USB-HDD", "USB-2")
s = s.replace("USB-HDD", (usb_name))
s = s.replace("内蔵HDD", "本体")


s = s.replace("視聴済", "済")
s = s.replace("未視聴", "未")
s = s.replace("視聴済み", "視聴済")
# s = s.replace("なし", "曜日")
# s = s.replace("なし", "開始時刻")


# ==========================================================



# ==========================================================
# =====　ジャンル　Replace Word 追加
# =====　2022-12-11-「笑点」のジャンル　置換
s = s.replace("演劇/公演", "演劇")
# ==========================================================
# s = s.replace("__", "")       # _ + 2

s = s.replace("＜スタンダードサイズ＞", "[S]")
s = s.replace("＜レターボックスサイズ＞", "[L]")
s = s.replace("＜字幕・レターボックスサイズ＞", "[字][L}")
s = s.replace("＜字幕スーパー＞", "[字]")



s = s.replace("[字]所さんの世田谷ベ―ス　", "世田谷ベ―ス")
s = s.replace("ＢＳニュース", "BSニュース")
s = s.replace("Ｗｏｒｌｄ＋Ｂｉｚ", "Word＋Biz")
s = s.replace("ワイルドライフ「", "ワ「")
s = s.replace("深層ＮＥＷＳ", "深層NEWS")
s = s.replace("[字]報道１９３０▼", "報道1930▽")
s = s.replace("[字]報道１９３０", "報道1930▽")
# 日経プラス９サタデー
s = s.replace("日経プラス９サタデー", "日経ﾌﾟﾗｽ9ｻﾀﾃﾞｰ")




s = s.replace("1.5倍録", "x1.5")
s = s.replace("10倍録", "x10")
s = s.replace("15倍録", "x15")
s = s.replace("3倍録", "x3")
s = s.replace("4倍録", "x4")
s = s.replace("5倍録", "x5")
s = s.replace("8倍録", "x8")
# ==========================================================
s = s.replace("CS2_3", "CS2 3")

s = s.replace("BS?101", "BS 101")
s = s.replace("BS?102", "BS 102")
s = s.replace("BS?103", "BS 103")
s = s.replace("BS?141", "BS 141")
s = s.replace("BS?151", "BS 151")
s = s.replace("BS?161", "BS 161")
s = s.replace("BS?171", "BS 171")
s = s.replace("BS?181", "BS 181")
s = s.replace("BS?191", "BS 191")
s = s.replace("BS?210", "BS 210")
s = s.replace("BS?211", "BS 211")
s = s.replace("BS?212", "BS 212")
s = s.replace("BS?213", "BS 213")
s = s.replace("BS?214", "BS 214")
s = s.replace("BS?215", "BS 215")
s = s.replace("BS?236", "BS 236")
s = s.replace("BS?238", "BS 238")
s = s.replace("BS?240", "BS 240")
s = s.replace("BS?241", "BS 241")
s = s.replace("BS?242", "BS 242")
s = s.replace("BS?243", "BS 243")
s = s.replace("BS?244", "BS 244")
s = s.replace("BS?245", "BS 245")
s = s.replace("BS?246", "BS 246")
s = s.replace("BS?247", "BS 247")
s = s.replace("BS?248", "BS 248")
s = s.replace("BS?249", "BS 249")
s = s.replace("BS?252", "BS 252")
s = s.replace("BS?258", "BS 258")
s = s.replace("BS_103", "BS 103")
s = s.replace("BS103", "BS 103")
s = s.replace("BS11イレブン", "BS11ｲﾚﾌﾞﾝ")
s = s.replace("BSフジ・181", "BSﾌｼﾞ")
s = s.replace("CS1?298", "CS1 298")
s = s.replace("CS1 298", "CS1 298")
s = s.replace("CS2?223", "CS2 223")
s = s.replace("CS2?240", "CS2 240")
s = s.replace("CS2?300", "CS2 300")
s = s.replace("CS2?301", "CS2 301")
s = s.replace("CS2?302", "CS2 302")
s = s.replace("CS2?303", "CS2 303")
s = s.replace("CS2?304", "CS2 304")
s = s.replace("CS2?305", "CS2 305")
s = s.replace("CS2?306", "CS2 306")
s = s.replace("CS2?307", "CS2 307")
s = s.replace("CS2?310", "CS2 310")
s = s.replace("CS2?311", "CS2 311")
s = s.replace("CS2?312", "CS2 312")
s = s.replace("CS2?313", "CS2 313")
s = s.replace("CS2?314", "CS2 314")
s = s.replace("CS2?315", "CS2 315")
s = s.replace("CS2?316", "CS2 316")
s = s.replace("CS2?317", "CS2 317")
s = s.replace("CS2?318", "CS2 318")
s = s.replace("CS2?319", "CS2 319")
s = s.replace("CS2?321", "CS2 321")
s = s.replace("CS2?322", "CS2 322")
s = s.replace("CS2?323", "CS2 323")
s = s.replace("CS2?325", "CS2 325")
s = s.replace("CS2?340", "CS2 340")
s = s.replace("CS2?341", "CS2 341")
s = s.replace("CS2?342", "CS2 342")
s = s.replace("CS2?343", "CS2 343")
s = s.replace("CS2?344", "CS2 344")
s = s.replace("CS2?345", "CS2 345")

s = s.replace("BS?101", "BS 101")
s = s.replace("BS?171", "BS 171")
s = s.replace("CS2?342", "CS 342")

s = s.replace("地上D?011", "地D 011")
s = s.replace("地上D?021", "地D 021")
s = s.replace("地上D?041", "地D 041")
s = s.replace("地上D?081", "地D 081")
s = s.replace("地上D?091", "地D 091")

# s = s.replace("NHKBSプレミアム", "NHKBSﾌﾟﾚﾐｱﾑ")
s = s.replace("NHKBSプレミアム", "BSﾌﾟﾚﾐｱﾑ")
s = s.replace("NHKEテレ1東京", "NHKEﾃﾚ")
s = s.replace("NHK総合1・東京", "NHK総合")
s = s.replace("TOKYO MX1", "東京MX")
s = s.replace("TOKYO　MX1", "東京MX")

s = s.replace("WOWOWプライム", "WOWOWﾌﾟﾗｲﾑ")
s = s.replace("アニメ/特撮", "ｱﾆﾒ特撮")
s = s.replace("エムオン!", "M-ON")
s = s.replace("スターチャンネル1", "ｽﾀｰﾁｬﾝﾈﾙ1")
s = s.replace("スターチャンネル2", "ｽﾀｰﾁｬﾝﾈﾙ2")
s = s.replace("スペシャプラス", "ｽﾍﾟｼｬﾌﾟﾗｽ")

s = s.replace("TOKYO　MX2", "TOKYO MX2")
s = s.replace("テレビ東京1", "ﾃﾚﾋﾞ東京1")
s = s.replace("ＢＳテレ東", "BSﾃﾚ東")
s = s.replace("ＢＳ松竹東急", "BS松竹東急")
# s = s.replace("ＢＳ松竹東急", "BS 260")
s = s.replace("テレビ朝日", "ﾃﾚﾋﾞ朝日")
s = s.replace("ドキュメンタリー/教養", "ﾄﾞｷｭ教養")
s = s.replace("趣味/教育", "趣味教育") # 2034-03-31-追加
s = s.replace("ニュース/報道", "報道")
s = s.replace("バラエティ", "ﾊﾞﾗｴﾃｨ")
s = s.replace("フジテレビ", "ﾌｼﾞﾃﾚﾋﾞ")

s = s.replace("情報/ワイドショー", "ﾜｲﾄﾞｼｮｰ")
s = s.replace("地デジ 011", "地D 011")
s = s.replace("地上D 031", "地D 031")
s = s.replace("地上D 091", "地D 091")
s = s.replace("地上D?011", "地D 011")
s = s.replace("地上D?021", "地D 021")
s = s.replace("地上D?031", "地D 031")
s = s.replace("地上D?041", "地D 041")
s = s.replace("地上D?051", "地D 051")
s = s.replace("地上D?061", "地D 061")
s = s.replace("地上D?071", "地D 071")
s = s.replace("地上D?081", "地D 081")
s = s.replace("地上D?091", "地D 091")

s = s.replace("地デジ 011", "地D 011")
s = s.replace("地デジ 021", "地D 021")
s = s.replace("地デジ 031", "地D 031")
s = s.replace("地デジ 041", "地D 041")
s = s.replace("地デジ 051", "地D 051")
s = s.replace("地デジ 061", "地D 061")
s = s.replace("地デジ 071", "地D 071")
s = s.replace("地デジ 081", "地D 081")
s = s.replace("地デジ 091", "地D 091")
# 地デジ 093	⇒	地D 093     2023-06-28-追加
s = s.replace("地デジ 093", "地D 093")

# ==========================================================
'''
NHKBSプレミアム
NHKEテレ1東京
BSフジ・181
NHKEテレ1東京
NHK総合1・東京
フジテレビ
テレビ朝日
BS朝日1
BS11イレブン
WOWOWプライム
TOKYO MX1
スターチャンネル2
エムオン!
スペシャプラス
'''
# ==========================================================
#   UTF-8 出力　拡張子 *.csv　出力 【　pandas　の　デフォリト　が　UTF-8】
# ==========================================================

with open("UTF-2W101-Replace済-本体-USB.csv", "w", encoding='UTF-8') as f:
    f.write(s)






'''
# 本日の処理したファイルの格納フォルダを作成
# now = datetime.datetime.now()
# now = datetime.date.now()
print('作成年月日')
t = date.today()
print(t)
today_dir = str(t)
# print('{0:%Y-%m-%d %H:%M}'.format(now)) #test_2017-09-10 10:12
# date_now = ('{0:%Y/%m/%d}'.format(now)) #test_2017-09-10 10:12
# time_now = ('{0:%H:%M}'.format(now)) #test_2017-09-10 10:12
# today_dir = str'(date_now)'
# print(today_dir)
# ws.cell(row=(line_no),column=7).value   = 'G-7   '+(date_now)+'   '+(time_now)
# os.makedirs((data_path) / 'PDF_a_to_z', exist_ok=True)
# os.makedirs((output_path) / '番組表-' / str'(date_now)', exist_ok=True)
# os.makedirs((today_dir), exist_ok=True)
os.makedirs('番組表-'+(today_dir), exist_ok=True)

#正規表現×glob.globでinput_path内のファイル全てをリストとして取得
move_file_list = glob.glob(input_path + "*.tsv")
'''
