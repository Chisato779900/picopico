#!/usr/bin/env python
# coding: utf-8

# =============== import
import pandas as pd
import numpy as np
import os
# =============== CD チェンジディレクトリ
os.chdir('C:\\pypy\\Dimora')
cwd = os.getcwd()
print(cwd)
# ==========================================================
# import の　直下
# 最大表示列の指定 None=制限なし
pd.set_option('display.max_columns', None) 
# 表示行の指定　５行
pd.set_option('display.max_rows', 2000)

# カラム名の先行指示　※カラム数が一定でない場合
# pandas.errors.ParserError: Error tokenizing data. C error: Expected 9 fields in line 20, saw 11
# みたいなエラーがでるため。昨年は（2022年は発生しなかったのにな）

col_names = ['c{0:02d}'.format(i) for i in range(25)]

# =============== ファイルの読み込み　read_csv
df_hdd = pd.read_csv('UTF-2W101-Replace済-本体-USB.csv',encoding='utf-8')
                     #UTF-2W101-Replace済-本体-USB
# INDEX 番号　0始まりを　次の一行命令で　1始まりにできる
# キノコード　pandas入門-抽出.mp4
df_hdd.index = df_hdd.index + 1

# =============== numpy を　使用した　列の追加挿入
df_hdd["日"]=np.nan
df_hdd["時間"]=np.nan
df_hdd["頁"]=np.nan
df_hdd["行"]=np.nan
# df_hdd["分分"]=np.nan
df_hdd["時:分"]=np.nan
# df_hdd["MOD2"]=np.nan
df_hdd["検索ワード"]=np.nan
df_hdd["番組MB"]=np.nan
df_hdd["残り時間"]=np.nan
# df_hdd["MOD3"]=np.nan
df_hdd["使用MB"]=np.nan
df_hdd["残りMB"]=np.nan
df_hdd["_MB"]=np.nan
df_hdd["率"]=np.nan

# =============== 列の削除
df_dell = df_hdd.drop(columns=['DMR-', '視聴/未'])
# ===============　カラム順番変更
# print(df.reindex(['B', 'C', 'A'], axis='columns'))
# =============== 2023-10-11まで
'''
df_dell2 = df_dell.reindex(['□放送開始日時□','日','時間','□放送局□',
                 'ｼﾞｬﾝﾙ','録画先','☆番組タイトル☆',
                 '頁','行','時:分','分','MODE','検索ワード',
                 '番組MB','残り時間',
                 '使用MB','残りMB','_MB','率'],axis='columns')
'''
# =============== 2023-10-11から変更-19:46
df_dell2 = df_dell.reindex(['□放送開始日時□','日','時間','□放送局□',
                 '☆番組タイトル☆','頁','行','時:分','MODE',
                 '分','検索ワード','ｼﾞｬﾝﾙ','録画先',
                 '番組MB','残り時間',
                 '使用MB','残りMB','_MB','率'],axis='columns')

# 項目削除⇒　'MOD2','MOD3',

# =============== 番組タイトルで　ソート
df_sort = df_dell2.sort_values(by='☆番組タイトル☆') # 昇順

# =============== ファイルの出力　エクセル形式で　出力　to_excel
df_sort[df_sort
        ['録画先'] == 'USB-1'].to_excel('2W101-USB-1-pandas-output.xlsx',encoding='utf-8',index=False)
# df_hdd[df_hdd['録画先'] == 'USB-1'].to_csv('UTF-2W101-USB-1-ONLY.csv',encoding='utf-8',index=False)
# df_hdd.fillna("None").to_csv('export.csv',encoding='utf-8',index=False)
# ==========================================================
